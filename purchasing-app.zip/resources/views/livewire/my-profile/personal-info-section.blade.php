<div>
    {{ $this->form }}
    <x-filament-actions::modals />
</div>
