<div {{ $getExtraAttributeBag() }}>
    {{ $getState() }}
</div>
