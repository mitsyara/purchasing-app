<x-filament-panels::page>
    <livewire:my-profile.personal-info-section />

    <livewire:my-profile.password-section />

    <livewire:my-profile.session-section />

    <livewire:my-profile.two-factor-authentication />

</x-filament-panels::page>
