<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'Filament\\Actions\\Imports\\Events\\ImportCompleted' => 
    array (
      0 => 'App\\Listeners\\FilamentJobImportCompleted@handle',
    ),
  ),
);