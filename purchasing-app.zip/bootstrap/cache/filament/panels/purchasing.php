<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.clusters.customs-data.customs-data-cluster' => 'App\\Filament\\Clusters\\CustomsData\\CustomsDataCluster',
    'app.filament.clusters.customs-data.pages.customs-data-report-by-category' => 'App\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCategory',
    'app.filament.clusters.customs-data.pages.customs-data-report-by-company' => 'App\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCompany',
    'app.filament.clusters.customs-data.resources.customs-data-by-importer-categories.pages.manage-customs-data-by-importer-categories' => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporterCategories\\Pages\\ManageCustomsDataByImporterCategories',
    'app.filament.clusters.customs-data.resources.customs-data-by-importers.pages.manage-customs-data-by-importers' => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporters\\Pages\\ManageCustomsDataByImporters',
    'app.filament.clusters.customs-data.resources.customs-data.pages.manage-customs-data' => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsData\\Pages\\ManageCustomsData',
    'app.filament.clusters.settings.pages.language' => 'App\\Filament\\Clusters\\Settings\\Pages\\Language',
    'app.filament.clusters.settings.pages.my-profile' => 'App\\Filament\\Clusters\\Settings\\Pages\\MyProfile',
    'app.filament.clusters.settings.pages.other-product-settings' => 'App\\Filament\\Clusters\\Settings\\Pages\\OtherProductSettings',
    'app.filament.clusters.settings.pages.user-activities' => 'App\\Filament\\Clusters\\Settings\\Pages\\UserActivities',
    'app.filament.clusters.settings.resources.assortments.pages.manage-assortments' => 'App\\Filament\\Clusters\\Settings\\Resources\\Assortments\\Pages\\ManageAssortments',
    'app.filament.clusters.settings.resources.categories.pages.manage-categories' => 'App\\Filament\\Clusters\\Settings\\Resources\\Categories\\Pages\\ManageCategories',
    'app.filament.clusters.settings.resources.companies.pages.manage-companies' => 'App\\Filament\\Clusters\\Settings\\Resources\\Companies\\Pages\\ManageCompanies',
    'app.filament.clusters.settings.resources.ports.pages.manage-ports' => 'App\\Filament\\Clusters\\Settings\\Resources\\Ports\\Pages\\ManagePorts',
    'app.filament.clusters.settings.resources.products.pages.manage-products' => 'App\\Filament\\Clusters\\Settings\\Resources\\Products\\Pages\\ManageProducts',
    'app.filament.clusters.settings.resources.users.pages.manage-users' => 'App\\Filament\\Clusters\\Settings\\Resources\\Users\\Pages\\ManageUsers',
    'app.filament.clusters.settings.resources.warehouses.pages.manage-warehouses' => 'App\\Filament\\Clusters\\Settings\\Resources\\Warehouses\\Pages\\ManageWarehouses',
    'app.filament.clusters.settings.settings-cluster' => 'App\\Filament\\Clusters\\Settings\\SettingsCluster',
    'app.filament.resources.contacts.pages.manage-contacts' => 'App\\Filament\\Resources\\Contacts\\Pages\\ManageContacts',
    'app.filament.resources.inventory-transactions.pages.manage-inventory-transactions' => 'App\\Filament\\Resources\\InventoryTransactions\\Pages\\ManageInventoryTransactions',
    'app.filament.resources.purchase-orders.pages.create-purchase-order' => 'App\\Filament\\Resources\\PurchaseOrders\\Pages\\CreatePurchaseOrder',
    'app.filament.resources.purchase-orders.pages.edit-purchase-order' => 'App\\Filament\\Resources\\PurchaseOrders\\Pages\\EditPurchaseOrder',
    'app.filament.resources.purchase-orders.pages.list-purchase-orders' => 'App\\Filament\\Resources\\PurchaseOrders\\Pages\\ListPurchaseOrders',
    'app.filament.resources.purchase-orders.pages.view-purchase-order' => 'App\\Filament\\Resources\\PurchaseOrders\\Pages\\ViewPurchaseOrder',
    'app.filament.resources.purchase-orders.relation-managers.purchase-order-lines-relation-manager' => 'App\\Filament\\Resources\\PurchaseOrders\\RelationManagers\\PurchaseOrderLinesRelationManager',
    'app.filament.resources.purchase-orders.relation-managers.purchase-shipments-relation-manager' => 'App\\Filament\\Resources\\PurchaseOrders\\RelationManagers\\PurchaseShipmentsRelationManager',
    'app.filament.resources.purchase-shipments.pages.manage-purchase-shipments' => 'App\\Filament\\Resources\\PurchaseShipments\\Pages\\ManagePurchaseShipments',
    'app.filament.pages.dashboard' => 'App\\Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'achyut-n.filament-log-viewer.log-table' => 'AchyutN\\FilamentLogViewer\\LogTable',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.auth.pages.edit-profile' => 'Filament\\Auth\\Pages\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.livewire.sidebar' => 'Filament\\Livewire\\Sidebar',
    'filament.livewire.simple-user-menu' => 'Filament\\Livewire\\SimpleUserMenu',
    'filament.livewire.topbar' => 'Filament\\Livewire\\Topbar',
    'filament.auth.pages.email-verification.email-verification-prompt' => 'Filament\\Auth\\Pages\\EmailVerification\\EmailVerificationPrompt',
    'filament.auth.pages.login' => 'Filament\\Auth\\Pages\\Login',
    'filament.auth.pages.password-reset.request-password-reset' => 'Filament\\Auth\\Pages\\PasswordReset\\RequestPasswordReset',
    'filament.auth.pages.password-reset.reset-password' => 'Filament\\Auth\\Pages\\PasswordReset\\ResetPassword',
  ),
  'clusters' => 
  array (
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\CustomsDataCluster.php' => 'App\\Filament\\Clusters\\CustomsData\\CustomsDataCluster',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\SettingsCluster.php' => 'App\\Filament\\Clusters\\Settings\\SettingsCluster',
  ),
  'clusteredComponents' => 
  array (
    'App\\Filament\\Clusters\\CustomsData\\CustomsDataCluster' => 
    array (
      0 => 'App\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCategory',
      1 => 'App\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCompany',
      2 => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporterCategories\\CustomsDataByImporterCategoryResource',
      3 => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporters\\CustomsDataByImporterResource',
      4 => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsData\\CustomsDataResource',
    ),
    'App\\Filament\\Clusters\\Settings\\SettingsCluster' => 
    array (
      0 => 'App\\Filament\\Clusters\\Settings\\Pages\\Language',
      1 => 'App\\Filament\\Clusters\\Settings\\Pages\\MyProfile',
      2 => 'App\\Filament\\Clusters\\Settings\\Pages\\OtherProductSettings',
      3 => 'App\\Filament\\Clusters\\Settings\\Resources\\Assortments\\AssortmentResource',
      4 => 'App\\Filament\\Clusters\\Settings\\Resources\\Categories\\CategoryResource',
      5 => 'App\\Filament\\Clusters\\Settings\\Resources\\Companies\\CompanyResource',
      6 => 'App\\Filament\\Clusters\\Settings\\Resources\\Ports\\PortResource',
      7 => 'App\\Filament\\Clusters\\Settings\\Resources\\Users\\UserResource',
      8 => 'App\\Filament\\Clusters\\Settings\\Resources\\Warehouses\\WarehouseResource',
    ),
  ),
  'clusterDirectories' => 
  array (
    0 => 'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament/Clusters',
  ),
  'clusterNamespaces' => 
  array (
    0 => 'App\\Filament\\Clusters',
  ),
  'pages' => 
  array (
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\CustomsDataCluster.php' => 'App\\Filament\\Clusters\\CustomsData\\CustomsDataCluster',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCategory.php' => 'App\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCategory',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCompany.php' => 'App\\Filament\\Clusters\\CustomsData\\Pages\\CustomsDataReportByCompany',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Pages\\Language.php' => 'App\\Filament\\Clusters\\Settings\\Pages\\Language',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Pages\\MyProfile.php' => 'App\\Filament\\Clusters\\Settings\\Pages\\MyProfile',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Pages\\OtherProductSettings.php' => 'App\\Filament\\Clusters\\Settings\\Pages\\OtherProductSettings',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Pages\\UserActivities.php' => 'App\\Filament\\Clusters\\Settings\\Pages\\UserActivities',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\SettingsCluster.php' => 'App\\Filament\\Clusters\\Settings\\SettingsCluster',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Pages\\Dashboard.php' => 'App\\Filament\\Pages\\Dashboard',
    0 => 'AchyutN\\FilamentLogViewer\\LogTable',
  ),
  'pageDirectories' => 
  array (
    0 => 'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporterCategories\\CustomsDataByImporterCategoryResource.php' => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporterCategories\\CustomsDataByImporterCategoryResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporters\\CustomsDataByImporterResource.php' => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsDataByImporters\\CustomsDataByImporterResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\CustomsData\\Resources\\CustomsData\\CustomsDataResource.php' => 'App\\Filament\\Clusters\\CustomsData\\Resources\\CustomsData\\CustomsDataResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Assortments\\AssortmentResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Assortments\\AssortmentResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Categories\\CategoryResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Categories\\CategoryResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Companies\\CompanyResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Companies\\CompanyResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Ports\\PortResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Ports\\PortResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Products\\ProductResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Products\\ProductResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Users\\UserResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Users\\UserResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Clusters\\Settings\\Resources\\Warehouses\\WarehouseResource.php' => 'App\\Filament\\Clusters\\Settings\\Resources\\Warehouses\\WarehouseResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Resources\\Contacts\\ContactResource.php' => 'App\\Filament\\Resources\\Contacts\\ContactResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Resources\\InventoryTransactions\\InventoryTransactionResource.php' => 'App\\Filament\\Resources\\InventoryTransactions\\InventoryTransactionResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Resources\\PurchaseOrders\\PurchaseOrderResource.php' => 'App\\Filament\\Resources\\PurchaseOrders\\PurchaseOrderResource',
    'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament\\Resources\\PurchaseShipments\\PurchaseShipmentResource.php' => 'App\\Filament\\Resources\\PurchaseShipments\\PurchaseShipmentResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'E:\\virtual_servers\\laragon\\www\\purchasing-app\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);