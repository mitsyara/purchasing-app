<?php

namespace App\Filament\Infolists\Components;

use Filament\Infolists\Components\Entry;

class ActivityChangesTable extends Entry
{
    protected string $view = 'filament.infolists.components.activity-changes-table';
}
