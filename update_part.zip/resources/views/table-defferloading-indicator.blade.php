<div wire:loading.flex wire:target="tableSearch,applyTableSearch,resetTableSearch,tableColumnSearches,resetTableColumnSearch,tableFilters,applyTableFilters,resetTableFiltersForm,nextPage,gotoPage,previousPage,tableRecordsPerPage,sortTable"
    class="custom-bg">
    <x-filament::loading-indicator class="h-8 w-8" />
</div>