const a = {
    "qty": "200",
    "unit": "Kilograms",
    "price": "1,6",
    "hscode": "29182100",
    "country": "CHINA",
    "product": "TRIDUR ZN H1 B (DR): sodium salicylate solution, Main ingredient: Cas 5421-46-5 (>= 15 -< 30%), 25kg/can",
    "exporter": "ATOTECH CHINA CHEMICALS LTD",
    "importer": "ATOTECH VIETNAM COMPANY LIMITED",
    "incoterm": "EXW",
    "import_date": "01/08/2025"
};
