<?php

namespace App\Filament\Schemas;

use Filament\Resources\RelationManagers\RelationManager;

use App\Models\PurchaseOrderLine;
use Illuminate\Database\Eloquent\Builder;

use Filament\Schemas\Schema;

use Filament\Forms\Components as F;
use Filament\Schemas\JsContent;

class POProductForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                // F\Select::make('assortment_id')
                //     ->label(__('Assortment'))
                //     ->relationship(
                //         name: 'assortment',
                //         titleAttribute: 'assortment_name',
                //         modifyQueryUsing: function (
                //             Builder $query,
                //             string $operation,
                //             \Livewire\Component $livewire,
                //             ?PurchaseOrderLine $record,
                //         ): Builder {
                //             if ($livewire instanceof RelationManager) {
                //                 $purchaseOrder = $livewire->getOwnerRecord();
                //                 $assortmentIds = $purchaseOrder->purchaseOrderLines()
                //                     ->when($record, fn(Builder $q) => $q->whereNot('id', $record->id))
                //                     ->pluck('assortment_id')
                //                     ->filter();
                //                 if ($assortmentIds) {
                //                     $query = $query->whereNotIn('id', $assortmentIds);
                //                 }
                //             }
                //             return $operation === 'create' ? $query->where('is_active', true) : $query;
                //         }
                //     )
                //     ->searchable()
                //     ->preload()
                //     ->disableOptionsWhenSelectedInSiblingRepeaterItems()
                //     ->afterStateUpdatedJs(<<<'JS'
                //         $state ? $set('product_id', null) : null;
                //     JS)
                //     ->live()
                //     ->skipRenderAfterStateUpdated()
                //     ->suffixAction(
                //         \Filament\Actions\Action::make('viewProductList')
                //             ->modal()->icon(Heroicon::Eye)->color('primary')
                //             ->schema(fn(F\Field $component) => [
                //                 I\RepeatableEntry::make('products')
                //                     ->hiddenLabel()
                //                     ->getStateUsing(
                //                         Product::whereIn('id', AssortmentProduct::whereAssortmentId($component->getState())->pluck('product_id'))
                //                             ->get()
                //                     )
                //                     ->schema([
                //                         I\TextEntry::make('product_full_name')
                //                             ->hiddenLabel()
                //                             ->copyable(),
                //                     ])
                //                     ->contained(false),
                //             ])
                //             ->modalSubmitAction(false)
                //             ->modalCancelActionLabel(__('Close'))
                //             ->disabled(fn(F\Field $component): bool => empty($component->getState())),
                //     )
                //     ->columnSpanFull()
                //     ->requiredWithout(['product_id']),

                F\Select::make('product_id')
                    ->label(__('Product'))
                    ->relationship(
                        name: 'product',
                        titleAttribute: 'product_full_name',
                        modifyQueryUsing: function (
                            Builder $query,
                            string $operation,
                            \Livewire\Component $livewire,
                            ?PurchaseOrderLine $record,
                        ): Builder {
                            if ($livewire instanceof RelationManager) {
                                $purchaseOrder = $livewire->getOwnerRecord();
                                $productIds = $purchaseOrder->purchaseOrderLines()
                                    ->when($record, fn(Builder $q) => $q->whereNot('id', $record->id))
                                    ->pluck('product_id')
                                    ->filter();
                                if ($productIds) {
                                    $query = $query->whereNotIn('id', $productIds);
                                }
                            }
                            return $operation === 'create'
                                ? $query->where('is_active', true)
                                : $query;
                        }
                    )
                    ->searchable()
                    ->preload()
                    ->disableOptionsWhenSelectedInSiblingRepeaterItems()
                    ->afterStateUpdatedJs(<<<'JS'
                        $state ? $set('assortment_id', null) : null;
                    JS)
                    ->columnSpanFull()
                    ->requiredWithout(['assortment_id']),

                __number_field('qty')
                    ->required(),

                __number_field('unit_price')
                    ->suffix(fn(\Livewire\Component $livewire)
                    => $livewire instanceof RelationManager
                        ? $livewire->getOwnerRecord()->currency
                        : JsContent::make(<<<'JS'
                        $get('../../currency')
                    JS))
                    ->required(),

                __number_field('contract_price')
                    ->suffix(fn(\Livewire\Component $livewire)
                    => $livewire instanceof RelationManager
                        ? $livewire->getOwnerRecord()->currency
                        : JsContent::make(<<<'JS'
                        $get('../../currency')
                    JS)),
            ]);
    }

    public static function repeaterHeaders(): array
    {
        return [
            // F\Repeater\TableColumn::make('Assortment')
            //     ->width('280px'),
            F\Repeater\TableColumn::make('Product'),
            F\Repeater\TableColumn::make('Qty')
                ->markAsRequired()
                ->width('180px'),
            F\Repeater\TableColumn::make('Unit Price')
                ->markAsRequired()
                ->width('180px'),
            F\Repeater\TableColumn::make('Contract Price')
                ->width('180px'),
        ];
    }
}
